/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drawingprogram;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 *
 * @author Iryna Naminat
 */
public class Rhombus extends Shape{

    private int topLeftX;
    private int topLeftY;
    private int width;
    private int height;
    private Color fillColor;
    private int [] x;
    private int [] y;
    
    
    /**
     * Constructor to build a circle
     * @param startX The top left X coordinate
     * @param startY The top left Y coordinate
     * @param width The width of the rectangle, in which the Rhombus will be inscribed
     * @param height The height of the rectangle, in which the Rhombus will be inscribed
     * @param lineColor The outline color of the rhombus
     */
    public Rhombus(int startX, int startY, int endX, int endY, Color lineColor, Color fillColor) {
        super(startX, startY, endX, endY, lineColor);
        this.fillColor = fillColor;

        // calculations for the rectangle, since it needs to know top left and width/height
        //where will be rhombus inscribed
        topLeftX = Math.min(startX, endX);
        topLeftY = Math.min(startY, endY);
        width = Math.abs(startX - endX);
        height = Math.abs(startY - endY);

    }
    
   /**
     * Draws the rhombus
     * @param g2d The graphics context needed for drawing
     */
     
    @Override
    public void draw(Graphics2D g2d) {
         // arrays to store coordintes of 4 vertices of rhombus
        int [] x ={topLeftX+width/2,topLeftX+width,topLeftX+width/2,topLeftX};
        int [] y ={topLeftY,topLeftY+height/2,topLeftY+height,topLeftY+height/2}; 
      
        // draw solid rhombus first 
        g2d.setColor(fillColor);
        g2d.fillPolygon(x, y, 4);

        // draw outline rhombus on top
        g2d.setColor(lineColor);
        g2d.drawPolygon(x, y, 4);
 
    }
    
    
     /**
     * This static method is used to draw a rhombus before an actual rhombus object is created
     * It is used to give the user interactive feedback as they are dragging the cursor
     * @param g2d The graphics context needed for drawing
     * @param x1 int x coordinate from where mouse pressed down
     * @param y1 int y coordinate from where mouse pressed down
     * @param x2 int x coordinate from where mouse released
     * @param y2 int y coordinate from where mouse released
     * @param lc Color for line color
     * @param fc Color for fill color
     */
    public static void draw(Graphics2D g2d, int x1, int y1, int x2, int y2, Color lc, Color fc) {
        g2d.setColor(fc);
        // arrays to store coordintes of 4 vertices of rhombus
        int x[] = {x1 + Math.abs(x2 - x1) / 2, x2, x1 + Math.abs(x2 - x1) / 2, x1};
        int y[] = {y1, y1 + Math.abs(y2 - y1) / 2, y2, y1 + Math.abs(y2 - y1) / 2};

        // draw solid rhombus first
        g2d.fillPolygon(x, y, 4);

        // draw outline on top
        g2d.setColor(lc);
        g2d.drawPolygon(x, y, 4);

    }

}
