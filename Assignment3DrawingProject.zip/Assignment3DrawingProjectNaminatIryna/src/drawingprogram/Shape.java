/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package drawingprogram;

import java.awt.Color;
import java.awt.Graphics2D;

/**
 *
 * @author Iryna Naminat
 */
 public abstract class Shape {
     
    protected int startX;
    protected int startY;
    protected int endX;
    protected int endY;
    protected Color lineColor;
   
    /**
     * Constructor to build any shape
     * @param startX The top left X coordinate
     * @param startY The top left Y coordinate
     * @param endX The bottom right X coordinate
     * @param endY The bottom right Y coordinate
     * @param lineColor The outline color of the circle
     */
 
        public Shape(int startX, int startY, int endX, int endY, Color lineColor) {
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;
        this.lineColor = lineColor;
      
    }
   
  /**
   * abstract method which will override for each shapes
   * @param g2d 
   */  
   abstract public void draw(Graphics2D g2d);
   
}
